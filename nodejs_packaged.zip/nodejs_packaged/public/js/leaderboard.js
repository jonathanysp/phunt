window.onload = function () {
	addLeaderboardEvents();
	//tell which game to listen to
	//register('0', null);
	//getInfo('0');
}