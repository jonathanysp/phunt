
var tasks = {};

tasks.sample = [
	'one',
	'two',
	'three',
	'four'
]

tasks.google = [
	'Ride a bike', 
	'Slide down building 2000',
	'Get a haircut',
	'Swim in the water treadmill', 
	'Eat out of an outdoor garden ',
	'Try on 5 items swag at the google store',
	'Find Sergey and Larry', 
	'Play in a ballpit'
]

exports.tasks = tasks;